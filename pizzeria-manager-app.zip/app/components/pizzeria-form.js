import Component from '@ember/component';

export default Component.extend({
    didReceiveAttrs() {
        this.populateArr();
    },
    actions: {
        save(pizzeria) {
            this.onSave(pizzeria);
        }
    }
});

// import Component from '@ember/component';
// import EmberObject from '@ember/object';
// import { A } from '@ember/array';

// export default Component.extend({
//     populatePizzaArr() {
//         this.get('checkedPizzas').addObjects(this.pizzeria.pizzas)
//             .map(pizza => {
//                 pizza.set('isChecked', false);
//                 return pizza;
//             })
//     },
//     pizzeria: null,
//     init() {
//         this._super(...arguments);
//         this.set('checkedPizzas', A());
//         this.set('newPizzeria', EmberObject.create({ name: '', address: '', hours: '' }));
//         this.populatePizzaArr();
//     },
//     actions: {
//         async savePizzeria(pizzeria) {
//             pizzeria.set('name', this.get('newPizzeria.name'));
//             pizzeria.set('address', this.get('newPizzeria.address'));
//             pizzeria.set('hours', this.get('newPizzeria.hours'));
//             let pizzaArr = [];
//             this.get('checkedPizzas').forEach(pizza => {
//                 if (pizza.isChecked) {
//                     pizzaArr.push({name: pizza.name, ingredients: pizza.ingredients, price: pizza.price });
//                 }
//             });
//             pizzeria.set('menu', pizzaArr);
//             await pizzeria.save();
//         }
//     }
// });