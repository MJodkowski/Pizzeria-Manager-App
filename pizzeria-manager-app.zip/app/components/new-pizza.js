import Component from '@ember/component';
import EmberObject from '@ember/object';
import { A } from '@ember/array';

export default Component.extend({
    pizza: null,  
    init() {
        this._super(...arguments);
        this.set('newPizza', EmberObject.create({ name: '', ingredients: A(), price: '' }));
    },
    ingredient: '',
    actions: {
        addIngredient () {
            this.get('newPizza.ingredients').pushObject(this.get('ingredient'));
            this.set('ingredient', '');
        },
        async savePizza(pizza) {
            pizza.set('name', this.get('newPizza.name'));
            pizza.set('ingredients', this.get('newPizza.ingredients'));
            pizza.set('price', this.get('newPizza.price'));
            await pizza.save();
        },
    }
});