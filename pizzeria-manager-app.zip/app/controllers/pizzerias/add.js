import Controller from '@ember/controller';
import { A } from '@ember/array';

export default Controller.extend({
    init() {
        this._super(...arguments);
        this.set('checkedPizzas', A());
    },
    actions: {
        populatePizzaArr() {
            this.get('checkedPizzas').addObjects(this.model.pizzas)
                .map(pizza => {
                    pizza.set('isChecked', false);
                    return pizza;
                })
        },
        async savePizzeria(pizzeria) {
            let pizzaArr = ['empty'];
            this.get('checkedPizzas').forEach(pizza => {
                if (pizza.isChecked) {
                    pizzaArr.push({ name: pizza.name, ingredients: pizza.ingredients, price: pizza.price });
                }
            });
            pizzeria.set('menu', pizzaArr);
            await pizzeria.save();
        }
    }
});
