import Controller from '@ember/controller';
import { A } from '@ember/array';

export default Controller.extend({
    init() {
        this._super(...arguments);
        this.set('checkedPizzas', A());
    },
    actions: {
        populatePizzaArr() {
            if (this.model.pizzeria.menu !== undefined) {
                this.get('checkedPizzas').addObjects(this.model.pizzas)
                .map(pizza => {
                    this.model.pizzeria.menu.find(item => item.name === pizza.name ? 
                        pizza.set('isChecked', true) : false) 
                    return pizza;
                });
            }
        },
        async savePizzeria(pizzeria) {
            let pizzaArr = [];
            this.get('checkedPizzas').forEach(pizza => {
                if (pizza.isChecked) {
                    pizzaArr.push({ name: pizza.name, ingredients: pizza.ingredients, price: pizza.price });
                }
            });
            pizzeria.set('menu', pizzaArr);
            await pizzeria.save();
        }
    }
});
